#!/usr/bin/env python3
# Made by Loia Labs LLC. Credit line only: no copyright claim is made in this file;
# licence terms are in the LICENSE of the record that carries it.
"""
zenodo_to_github.py  (prototype)

Direction: Zenodo first, GitHub second. Takes a PUBLISHED Zenodo record, pulls every
published version through Zenodo's public API (no token), checks each file against the
checksum Zenodo lists, and builds a local git repository with one commit and one tag per
Zenodo version. It never pushes. It writes push_commands.sh for the author to read and run.

Standard library only.

Usage
  python3 zenodo_to_github.py RECORD_ID --out DIR            (first run)
  python3 zenodo_to_github.py --update --out DIR            (later: add only new Zenodo versions)
  python3 zenodo_to_github.py --fixture FIXTURE_DIR --out DIR      (offline test)

Do NOT switch this GitHub repository on under Zenodo > Settings > GitHub. If it is
switched on, every GitHub release would create a second Zenodo record of the same work.
"""
import argparse, hashlib, html, html.parser, io, json, os, re, shutil, subprocess, sys
import urllib.error, urllib.request, zipfile

PRIVATE_NAMES = ["superserpynt ii", "superserpynt_ii", "apery_kit", "space_models", "space models",
                 "private_backup", "do_not_share", "c engine", "c_engine"]
MACHINE_PATHS = re.compile(r"(/mnt/|/home/|/root/|/tmp/|[A-Za-z]:\\\\Users\\\\)")
GITHUB_FILE_LIMIT = 100 * 1024 * 1024   # GitHub refuses single files over 100 MB in a push

# ---------------------------------------------------------------- fetching
def get_json(url):
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.load(r)

def get_bytes(url):
    with urllib.request.urlopen(url, timeout=600) as r:
        return r.read()

def file_entries(rec):
    """Zenodo returns files either as a list (records endpoint) or under 'entries' (files endpoint)."""
    f = rec.get("files", [])
    if isinstance(f, dict):
        f = f.get("entries", [])
    out = []
    for e in f:
        links = e.get("links", {})
        out.append({"key": e.get("key") or e.get("filename"),
                    "size": int(e.get("size") or e.get("filesize") or 0),
                    "checksum": e.get("checksum", ""),
                    "url": links.get("content") or links.get("self") or links.get("download")})
    return out

def all_versions(rec, fixture=None):
    if fixture:
        return [json.load(open(os.path.join(fixture, n))) for n in sorted(os.listdir(fixture))
                if n.startswith("record_") and n.endswith(".json")]
    vurl = rec.get("links", {}).get("versions")
    if not vurl:
        return [rec]
    sep = "&" if "?" in vurl else "?"
    hits, page, size = [], 1, 25
    while True:
        try:
            data = get_json(f"{vurl}{sep}size={size}&page={page}")
        except urllib.error.HTTPError as e:
            if page == 1 and e.code == 400:
                data = get_json(vurl)          # plain request, Zenodo's default paging
                hits = data.get("hits", {}).get("hits", [])
                total = data.get("hits", {}).get("total", len(hits))
                if isinstance(total, dict):
                    total = total.get("value", len(hits))
                if total > len(hits):
                    raise SystemExit(f"STOP: Zenodo lists {total} versions but returned {len(hits)}; paging refused")
                break
            raise
        batch = data.get("hits", {}).get("hits", [])
        hits += batch
        total = data.get("hits", {}).get("total", len(hits))
        if isinstance(total, dict):
            total = total.get("value", len(hits))
        if not batch or len(hits) >= total:
            break
        page += 1
    # Zenodo can list the same version twice across pages; keep one copy per id
    seen, out = set(), []
    for h in hits:
        if str(h.get("id")) not in seen:
            seen.add(str(h.get("id"))); out.append(h)
    return out or [rec]

def sort_key(r):
    m = r.get("metadata", {})
    return (m.get("publication_date", ""), str(r.get("id", "")))

# ---------------------------------------------------------------- checks
def verify(blob, entry):
    algo, _, want = entry["checksum"].partition(":")
    if entry["size"] and len(blob) != entry["size"]:
        return f"size {len(blob)} != listed {entry['size']}"
    if algo in ("md5", "sha256"):
        got = hashlib.new(algo, blob).hexdigest()
        if got.lower() != want.lower():
            return f"{algo} {got} != listed {want}"
        return None
    return f"no usable checksum listed ({entry['checksum']!r})"

def scan_text(name, text, problems):
    low = text.lower()
    for p in PRIVATE_NAMES:
        if re.search(r"(?<![a-z0-9_])" + re.escape(p) + r"(?![a-z0-9])", low):
            problems.append(f"{name}: contains private name '{p}'")
    for m in MACHINE_PATHS.finditer(text):
        problems.append(f"{name}: machine path '{m.group(0)}'")

def scan_blob(name, blob, problems, notes):
    if name.lower().endswith(".zip"):
        try:
            z = zipfile.ZipFile(io.BytesIO(blob))
        except zipfile.BadZipFile:
            problems.append(f"{name}: not a readable zip"); return
        sums = {}
        for info in z.infolist():
            if info.is_dir():
                continue
            data = z.read(info)
            scan_one(f"{name}!{info.filename}", data, problems, notes)
            if info.filename.endswith("SHA256SUMS.txt"):
                base = info.filename[: -len("SHA256SUMS.txt")]
                for line in data.decode("utf-8", "replace").splitlines():
                    parts = line.split()
                    if len(parts) == 2:
                        sums[base + parts[1].lstrip("*").lstrip("./")] = parts[0].lower()
        for path, want in sums.items():
            try:
                got = hashlib.sha256(z.read(path)).hexdigest()
            except KeyError:
                problems.append(f"{name}: SHA256SUMS lists missing file {path}"); continue
            if got != want:
                problems.append(f"{name}: SHA256SUMS mismatch for {path}")
        if sums:
            notes.append(f"{name}: SHA256SUMS.txt inside the zip checked, {len(sums)} entries")
    else:
        scan_one(name, blob, problems, notes)

def scan_one(name, data, problems, notes):
    if b"\0" in data[:4096]:
        return
    text = data.decode("utf-8", "replace")
    scan_text(name, text, problems)
    if name.endswith(".py") and "Made by Loia Labs LLC" not in text[:600]:
        notes.append(f"{name}: no Loia Labs credit header (already published; report only)")

# ---------------------------------------------------------------- HTML description -> Markdown
class H2M(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.out = []; self.href = None; self.lt = []
    def handle_starttag(self, t, a):
        a = dict(a)
        if t in ("h1", "h2", "h3", "h4"): self.out.append("\n\n" + "#" * (int(t[1]) + 1) + " ")
        elif t == "p": self.out.append("\n\n")
        elif t == "br": self.out.append("\n")
        elif t == "li": self.out.append("\n- ")
        elif t in ("strong", "b"): self.out.append("**")
        elif t in ("em", "i"): self.out.append("*")
        elif t == "a": self.href = a.get("href"); self.out.append("[")
    def handle_endtag(self, t):
        if t in ("strong", "b"): self.out.append("**")
        elif t in ("em", "i"): self.out.append("*")
        elif t == "a": self.out.append(f"]({self.href})" if self.href else "]"); self.href = None
        elif t in ("ul", "ol"): self.out.append("\n")
    def handle_data(self, d): self.out.append(d)

def html_to_md(s):
    p = H2M(); p.feed(s or ""); txt = "".join(p.out)
    return re.sub(r"\n{3,}", "\n\n", txt).strip()

# ---------------------------------------------------------------- repo files
def creators(meta):
    out = []
    for c in meta.get("creators", []):
        name = c.get("name") or c.get("person_or_org", {}).get("name", "")
        fam, _, giv = name.partition(",")
        d = {"family-names": fam.strip(), "given-names": giv.strip()} if giv else {"name": name}
        orcid = c.get("orcid") or ""
        if orcid:
            d["orcid"] = "https://orcid.org/" + orcid.split("/")[-1]
        out.append(d)
    return out

def yaml_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'

def citation_cff(rec, latest):
    m = latest.get("metadata", {})
    lic = m.get("license", {})
    lic = lic.get("id", "") if isinstance(lic, dict) else lic
    lines = ["cff-version: 1.2.0",
             "message: \"Please cite the Zenodo record (DOI below), which is the record of origin.\"",
             f"title: {yaml_str(m.get('title', ''))}",
             "authors:"]
    for c in creators(m):
        first = True
        for k, v in c.items():
            lines.append(("  - " if first else "    ") + f"{k}: {yaml_str(v)}"); first = False
    if latest.get("conceptdoi"):
        lines.append(f"doi: {yaml_str(latest['conceptdoi'])}")
    if m.get("version"):
        lines.append(f"version: {yaml_str(m['version'])}")
    if m.get("publication_date"):
        lines.append(f"date-released: {yaml_str(m['publication_date'])}")
    if lic:
        lines.append(f"license: {yaml_str(lic.upper() if lic.lower().startswith('cc') else lic)}")
    lines.append(f"url: {yaml_str('https://doi.org/' + latest.get('doi', ''))}")
    return "\n".join(lines) + "\n"

def readme(latest, versions, fps):
    m = latest.get("metadata", {})
    cdoi = latest.get("conceptdoi", "")
    rows = "\n".join(f"| {v.get('metadata', {}).get('version', '') or '-'} | "
                     f"{v.get('metadata', {}).get('publication_date', '')} | "
                     f"[{v.get('doi', '')}](https://doi.org/{v.get('doi', '')}) |" for v in versions)
    frows = "\n".join(f"| `{k}` | {fp[:16]} | {sz} |" for k, (fp, sz) in sorted(fps.items()))
    return f"""# {m.get('title', '')}

## Record of origin

This repository is a mirror of a Zenodo record. The Zenodo record is the record of origin;
cite it, not this repository.

All versions: [{cdoi}](https://doi.org/{cdoi})

## Description

{html_to_md(m.get('description', ''))}

## Versions

Each Zenodo version is one commit and one git tag here.

| Version | Published | DOI |
|---|---|---|
{rows}

## Files in the latest version

Fingerprint is the first 16 hex digits of SHA-256. Zenodo's own checksum was checked on download.

| File | Fingerprint | Bytes |
|---|---|---|
{frows}

## Mirror note

Made with zenodo_to_github.py (Loia Labs LLC). This repository is not switched on in
Zenodo's GitHub settings, so GitHub releases here do not create Zenodo records.
"""

# ---------------------------------------------------------------- main
STATE_FILE = "MIRROR_STATE.json"

def git(out, *args, env=None, check=True):
    return subprocess.run(["git", "-C", out, *args], capture_output=True, text=True, check=check, env=env)

def tree_matches_sums(out):
    """Every line of the repo's SHA256SUMS.txt must match the file on disk."""
    bad = []
    p = os.path.join(out, "SHA256SUMS.txt")
    if not os.path.exists(p):
        return ["SHA256SUMS.txt missing"]
    for line in open(p).read().splitlines():
        fp, path = line.split(None, 1)
        f = os.path.join(out, path)
        if not os.path.exists(f):
            bad.append(f"{path} missing")
        elif hashlib.sha256(open(f, "rb").read()).hexdigest() != fp:
            bad.append(f"{path} changed since it was mirrored")
    return bad

def run(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("record", nargs="?")
    ap.add_argument("--out", default="mirror_repo")
    ap.add_argument("--api", default="https://zenodo.org/api")
    ap.add_argument("--fixture")
    ap.add_argument("--update", action="store_true",
                    help="add only the Zenodo versions newer than those already in --out")
    ap.add_argument("--repo", help="existing git repository holding many records; each record goes to "
                    "records/zenodo-<concept id>/ and its tags are prefixed zenodo-<concept id>-")
    ap.add_argument("--no-git", action="store_true")
    a = ap.parse_args(argv)
    if a.record:
        mm = re.search(r"(\d+)\s*/?\s*$", a.record.split("?")[0])
        a.record = mm.group(1) if mm else a.record     # accepts a number or a zenodo.org/records/NNN link
    report = []
    root, rel, tagpre = None, ".", "v"
    if a.repo:
        if not os.path.isdir(os.path.join(a.repo, ".git")):
            sys.exit(f"STOP: {a.repo} is not a git repository")
        first = (all_versions(None, a.fixture)[0] if a.fixture
                 else get_json(f"{a.api}/records/{a.record}"))
        concept = str(first.get("conceptrecid") or (first.get("conceptdoi") or "").split(".")[-1] or first.get("id"))
        rel = os.path.join("records", f"zenodo-{concept}")
        root, a.out, tagpre = a.repo, os.path.join(a.repo, rel), f"zenodo-{concept}-v"
        a.update = os.path.exists(os.path.join(a.out, STATE_FILE))
        report.append(f"repository mode: record folder {rel} ({'update' if a.update else 'first run'})")
    parent = os.path.dirname(os.path.abspath(a.out)) or "."

    # ---- state of the target folder
    if a.update:
        if a.no_git or not shutil.which("git"):
            sys.exit("STOP: update mode needs git")
        if not os.path.isdir(os.path.join(root or a.out, ".git")):
            sys.exit(f"STOP: {a.out} is not a mirror repository (no .git)")
        sp = os.path.join(a.out, STATE_FILE)
        if not os.path.exists(sp):
            sys.exit(f"STOP: {a.out} has no {STATE_FILE}; it was not made by this tool")
        state = json.load(open(sp))
        if git(root or a.out, "status", "--porcelain", "--", rel).stdout.strip():
            sys.exit(f"STOP: {a.out} has uncommitted changes; the mirror must match its last commit")
        drift = tree_matches_sums(a.out)
        if drift:
            sys.exit("STOP: the repository no longer matches its own SHA256SUMS.txt: " + "; ".join(drift))
        if not a.record and not a.fixture:
            a.record = str(state["mirrored"][-1])
        report.append(f"update mode: {len(state['mirrored'])} version(s) already mirrored, "
                      f"last {state['mirrored'][-1]}; repository matches its SHA256SUMS.txt")
    else:
        if os.path.exists(a.out) and os.listdir(a.out):
            sys.exit(f"STOP: {a.out} exists and is not empty (use --update to add new versions)")
        os.makedirs(a.out, exist_ok=True)
        state = {"mirrored": []}

    # ---- fetch versions from Zenodo
    if a.fixture:
        recs = all_versions(None, a.fixture)
    else:
        if not a.record:
            ap.error("give a RECORD_ID or --fixture")
        recs = all_versions(get_json(f"{a.api}/records/{a.record}"))
    recs = sorted(recs, key=sort_key)
    ids = [str(r.get("id")) for r in recs]
    done = [str(x) for x in state["mirrored"]]

    # every mirrored version must still be on Zenodo, and they must be the oldest ones, in order
    missing = [x for x in done if x not in ids]
    if missing:
        sys.exit(f"STOP: mirrored record(s) {missing} are not in Zenodo's version list for this record")
    if ids[:len(done)] != done:
        sys.exit(f"STOP: Zenodo's oldest versions {ids[:len(done)]} differ from the mirrored ones {done} "
                 "(a version was added out of date order); nothing changed")
    new = recs[len(done):]
    if not new:
        report.append("nothing new on Zenodo; nothing changed")

    git_ok = (not a.no_git) and shutil.which("git")
    if git_ok and not a.update and not root:
        git(a.out, "init", "-q", "-b", "main")
    G = root or a.out
    existing_tags = set(git(G, "tag").stdout.split()) if git_ok else set()

    added = 0
    for i, rec in enumerate(recs, 1):
        if i <= len(done):
            continue
        m = rec.get("metadata", {})
        ver = m.get("version") or f"zenodo-{rec.get('id')}"
        tag = f"{tagpre}{ver}".replace(" ", "_")
        problems, notes, fps, blobs = [], [], {}, {}
        if tag in existing_tags:
            problems.append(f"tag {tag} already exists in the repository")
        for e in file_entries(rec):
            blob = get_bytes(e["url"])
            err = verify(blob, e)
            if err:
                problems.append(f"{e['key']}: {err}")
            if len(blob) > GITHUB_FILE_LIMIT:
                problems.append(f"{e['key']}: {len(blob)} bytes is over GitHub's 100 MB file limit (attach to a release instead)")
            scan_blob(e["key"], blob, problems, notes)
            fps[e["key"]] = (hashlib.sha256(blob).hexdigest(), len(blob))
            blobs[e["key"]] = blob
        report.append(f"version {ver}  record {rec.get('id')}  doi {rec.get('doi')}  files {len(fps)}")
        report += ["  PROBLEM " + p for p in problems] + ["  note " + n for n in notes]
        if problems:
            report.append("  STOP: this version was not staged. Nothing after it was staged either.")
            break
        for n in os.listdir(a.out):
            if n != ".git":
                q = os.path.join(a.out, n)
                shutil.rmtree(q) if os.path.isdir(q) else os.remove(q)
        os.makedirs(os.path.join(a.out, "files"))
        for k, b in blobs.items():
            open(os.path.join(a.out, "files", k), "wb").write(b)
        open(os.path.join(a.out, "README.md"), "w").write(readme(rec, recs[:i], fps))
        open(os.path.join(a.out, "CITATION.cff"), "w").write(citation_cff(rec, rec))
        json.dump(rec, open(os.path.join(a.out, "ZENODO_RECORD.json"), "w"), indent=2, sort_keys=True)
        with open(os.path.join(a.out, "SHA256SUMS.txt"), "w") as f:
            for k, (fp, _) in sorted(fps.items()):
                f.write(f"{fp}  files/{k}\n")
        state["mirrored"].append(str(rec.get("id")))
        json.dump(state, open(os.path.join(a.out, STATE_FILE), "w"), indent=2)
        if git_ok:
            date = m.get("publication_date", "") + "T12:00:00"
            env = dict(os.environ, GIT_AUTHOR_DATE=date, GIT_COMMITTER_DATE=date)
            git(G, "add", "-A", "--", rel)
            git(G, "-c", "user.name=Loia Labs LLC mirror", "-c", "user.email=loiasciences@gmail.com",
                "commit", "-q", "-m", f"Zenodo version {ver} ({rel})\n\nDOI: https://doi.org/{rec.get('doi')}", env=env)
            git(G, "tag", tag)
        added += 1

    with open(os.path.join(parent, "push_commands.sh"), "w") as f:
        f.write("# Made by Loia Labs LLC. Credit line only: no copyright claim is made in this file;\n"
                "# licence terms are in the LICENSE of the record that carries it.\n"
                "# Read MIRROR_REPORT.txt first. These commands publish to GitHub; run them yourself.\n"
                "# Do NOT switch this repository on under Zenodo > Settings > GitHub.\n"
                f"cd {os.path.abspath(a.out)}\n")
        if a.update:
            f.write("git push origin main\ngit push origin --tags\n" if added else "# nothing new to push\n")
        else:
            f.write("gh repo create REPO_NAME --public --source . --push\ngit push origin --tags\n")
    report.append(f"versions added this run: {added}")
    with open(os.path.join(parent, "MIRROR_REPORT.txt"), "w") as f:
        f.write("\n".join(report) + "\n")
    print("\n".join(report))
    return 0 if not any("STOP" in r for r in report) else 1

def main():
    try:
        return run()
    except SystemExit:
        raise
    except Exception as e:                      # write what happened where the workflow looks for it
        msg = f"STOP: {type(e).__name__}: {e}"
        for d in ("records", "."):
            if os.path.isdir(d):
                open(os.path.join(d, "MIRROR_REPORT.txt"), "w").write(msg + "\n"); break
        print(msg)
        return 1

if __name__ == "__main__":
    sys.exit(main())

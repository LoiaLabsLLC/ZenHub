# Made by Loia Labs LLC. Credit line only: no copyright claim is made in this file;
# licence terms are in the LICENSE of the record that carries it.
# Offline test of zenodo_to_github.py with made-up records served as file:// URLs.
import hashlib, io, json, os, shutil, subprocess, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import zenodo_to_github as z

def mkzip(files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as zf:
        sums = ""
        for n, d in files.items():
            zf.writestr(n, d); sums += hashlib.sha256(d).hexdigest() + "  " + n + "\n"
        zf.writestr("SHA256SUMS.txt", sums)
    return b.getvalue()

def fixture(root, versions):
    fx = os.path.join(root, "fx"); os.makedirs(fx)
    for i, (ver, date, files, bad_md5) in enumerate(versions, 1):
        entries = []
        for name, data in files.items():
            p = os.path.join(fx, f"v{i}_{name}"); open(p, "wb").write(data)
            md5 = hashlib.md5(data).hexdigest()
            entries.append({"key": name, "size": len(data),
                            "checksum": "md5:" + ("0" * 32 if bad_md5 else md5),
                            "links": {"self": "file://" + p}})
        rec = {"id": 1000 + i, "doi": f"10.5281/zenodo.{1000+i}", "conceptdoi": "10.5281/zenodo.999",
               "metadata": {"title": "Test note", "version": ver, "publication_date": date,
                            "license": {"id": "cc-by-4.0"},
                            "creators": [{"name": "Author, Test"}],
                            "description": "<h2>Summary</h2><p>A <strong>test</strong> record.</p><ul><li>one</li></ul>"},
               "files": entries}
        json.dump(rec, open(os.path.join(fx, f"record_{i:03d}.json"), "w"))
    return fx

res = []
def check(tag, cond, msg):
    res.append(f"{tag} {'PASS' if cond else 'FAIL'}: {msg}")

script = "# Made by Loia Labs LLC. Credit line only: no copyright claim is made in this file;\nprint(1)\n".encode()
# T1: two good versions -> two commits, two tags, README headings, CITATION doi
with tempfile.TemporaryDirectory() as t:
    fx = fixture(t, [("1", "2026-11-01", {"paper.pdf": b"%PDF-1.4 v1", "code.zip": mkzip({"a.py": script})}, False),
                     ("2", "2026-11-15", {"paper.pdf": b"%PDF-1.4 v2", "code.zip": mkzip({"a.py": script})}, False)])
    out = os.path.join(t, "repo")
    rc = z.run(["--fixture", fx, "--out", out])
    log = subprocess.run(["git", "-C", out, "log", "--format=%s %ad", "--date=short"], capture_output=True, text=True).stdout
    tags = subprocess.run(["git", "-C", out, "tag"], capture_output=True, text=True).stdout.split()
    rd = open(os.path.join(out, "README.md")).read()
    cff = open(os.path.join(out, "CITATION.cff")).read()
    check("T1", rc == 0 and tags == ["v1", "v2"] and log.count("Zenodo version") == 2
          and "2026-11-15" in log and "2026-11-01" in log, f"two versions -> commits and tags {tags}")
    check("T2", "### Summary" in rd and "**test**" in rd and "- one" in rd and "10.5281/zenodo.1002" in rd,
          "README keeps description headings and lists both version DOIs")
    check("T3", 'doi: "10.5281/zenodo.999"' in cff and 'family-names: "Author"' in cff, "CITATION.cff carries the concept DOI and author")
    sums = open(os.path.join(out, "SHA256SUMS.txt")).read()
    ok = all(hashlib.sha256(open(os.path.join(out, l.split()[1]), "rb").read()).hexdigest() == l.split()[0]
             for l in sums.splitlines())
    check("T4", ok, "SHA256SUMS.txt in the repo matches the staged files")
    check("T5", os.path.exists(os.path.join(t, "push_commands.sh")) and
          subprocess.run(["git", "-C", out, "remote"], capture_output=True, text=True).stdout == "",
          "no remote set and nothing pushed; push_commands.sh written for the author")
# T6: bad checksum in version 2 -> stop, only v1 staged
with tempfile.TemporaryDirectory() as t:
    fx = fixture(t, [("1", "2026-11-01", {"paper.pdf": b"v1"}, False), ("2", "2026-11-15", {"paper.pdf": b"v2"}, True)])
    out = os.path.join(t, "repo")
    rc = z.run(["--fixture", fx, "--out", out])
    tags = subprocess.run(["git", "-C", out, "tag"], capture_output=True, text=True).stdout.split()
    check("T6", rc == 1 and tags == ["v1"], "checksum mismatch stops at that version (only v1 tagged)")
# T7: private name and machine path inside a zip -> stop, nothing staged
with tempfile.TemporaryDirectory() as t:
    fx = fixture(t, [("1", "2026-11-01", {"code.zip": mkzip({"b.py": b"import apery_kit\nopen('/home/x')\n"})}, False)])
    out = os.path.join(t, "repo")
    rc = z.run(["--fixture", fx, "--out", out])
    rep = open(os.path.join(t, "MIRROR_REPORT.txt")).read()
    tags = subprocess.run(["git", "-C", out, "tag"], capture_output=True, text=True).stdout.split()
    check("T7", rc == 1 and tags == [] and "apery_kit" in rep and "/home/" in rep, "private name and machine path block staging")
# T8: SHA256SUMS mismatch inside a zip -> stop
with tempfile.TemporaryDirectory() as t:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as zf:
        zf.writestr("a.txt", "hello"); zf.writestr("SHA256SUMS.txt", "0" * 64 + "  a.txt\n")
    fx = fixture(t, [("1", "2026-11-01", {"code.zip": b.getvalue()}, False)])
    rc = z.run(["--fixture", fx, "--out", os.path.join(t, "repo")])
    check("T8", rc == 1 and "SHA256SUMS mismatch" in open(os.path.join(t, "MIRROR_REPORT.txt")).read(),
          "a wrong SHA256SUMS line inside a deposited zip is caught")

# ---------------- update mode
def add_version(fx, i, ver, date, files, rid=None, concept="999"):
    entries = []
    for name, data in files.items():
        q = os.path.join(fx, f"v{i}_{name}"); open(q, "wb").write(data)
        entries.append({"key": name, "size": len(data), "checksum": "md5:" + hashlib.md5(data).hexdigest(),
                        "links": {"self": "file://" + q}})
    rid = rid or 1000 + i
    rec = {"id": rid, "doi": f"10.5281/zenodo.{rid}", "conceptdoi": f"10.5281/zenodo.{concept}",
           "metadata": {"title": "Test note", "version": ver, "publication_date": date,
                        "license": {"id": "cc-by-4.0"}, "creators": [{"name": "Author, Test"}],
                        "description": "<h2>Summary</h2><p>x</p>"}, "files": entries}
    json.dump(rec, open(os.path.join(fx, f"record_{i:03d}.json"), "w"))

def tags_of(out):
    return subprocess.run(["git", "-C", out, "tag"], capture_output=True, text=True).stdout.split()

def stops(argv):
    try:
        return z.run(argv) == 1
    except SystemExit as e:
        return str(e.code).startswith("STOP")

with tempfile.TemporaryDirectory() as t:
    fx = os.path.join(t, "fx"); os.makedirs(fx); out = os.path.join(t, "repo")
    add_version(fx, 1, "1", "2026-11-01", {"paper.pdf": b"v1"})
    z.run(["--fixture", fx, "--out", out])
    # U1: nothing new -> no new commit
    n0 = subprocess.run(["git", "-C", out, "rev-list", "--count", "HEAD"], capture_output=True, text=True).stdout.strip()
    rc = z.run(["--update", "--fixture", fx, "--out", out])
    n1 = subprocess.run(["git", "-C", out, "rev-list", "--count", "HEAD"], capture_output=True, text=True).stdout.strip()
    check("U1", rc == 0 and n0 == n1 == "1" and "nothing new" in open(os.path.join(t, "MIRROR_REPORT.txt")).read(),
          "update with nothing new on Zenodo changes nothing")
    # U2: two new versions on Zenodo -> only those added, in order
    add_version(fx, 2, "2", "2026-11-10", {"paper.pdf": b"v2"})
    add_version(fx, 3, "3", "2026-11-20", {"paper.pdf": b"v3", "extra.txt": b"new file"})
    rc = z.run(["--update", "--fixture", fx, "--out", out])
    st = json.load(open(os.path.join(out, "MIRROR_STATE.json")))
    rd = open(os.path.join(out, "README.md")).read()
    check("U2", rc == 0 and tags_of(out) == ["v1", "v2", "v3"] and st["mirrored"] == ["1001", "1002", "1003"]
          and open(os.path.join(out, "files", "paper.pdf"), "rb").read() == b"v3"
          and all(f"zenodo.{k}" in rd for k in (1001, 1002, 1003))
          and "git push origin main" in open(os.path.join(t, "push_commands.sh")).read(),
          "update adds only the two new versions, tags v2 v3, README lists all three DOIs")
    # U3: a mirrored file edited by hand and committed -> drift stop
    open(os.path.join(out, "files", "paper.pdf"), "wb").write(b"tampered")
    subprocess.run(["git", "-C", out, "-c", "user.name=x", "-c", "user.email=x@x", "commit", "-qam", "edit"])
    add_version(fx, 4, "4", "2026-11-25", {"paper.pdf": b"v4"})
    check("U3", stops(["--update", "--fixture", fx, "--out", out]) and "v4" not in tags_of(out),
          "a repository that no longer matches its own SHA256SUMS.txt is refused")
    subprocess.run(["git", "-C", out, "reset", "-q", "--hard", "v3"])
    # U4: uncommitted change -> stop
    open(os.path.join(out, "stray.txt"), "w").write("x")
    check("U4", stops(["--update", "--fixture", fx, "--out", out]) and "v4" not in tags_of(out),
          "uncommitted changes in the repository are refused")
    os.remove(os.path.join(out, "stray.txt"))
    # U5: a version dated before the mirrored ones appears on Zenodo -> stop, nothing changed
    add_version(fx, 0, "0.9", "2026-10-01", {"paper.pdf": b"old"}, rid=999)
    check("U5", stops(["--update", "--fixture", fx, "--out", out]) and tags_of(out) == ["v1", "v2", "v3"],
          "a version out of date order is refused and nothing changes")
    os.remove(os.path.join(fx, "record_000.json"))
    # U6: clean repo again -> v4 added
    rc = z.run(["--update", "--fixture", fx, "--out", out])
    check("U6", rc == 0 and tags_of(out) == ["v1", "v2", "v3", "v4"], "after the problems are cleared, v4 is added")
    # U7: first-run mode on an existing repo is refused
    check("U7", stops(["--fixture", fx, "--out", out]), "a first run into a non-empty folder is refused")

# ---------------- repository mode (the ZenHub layout: many records in one repo)
with tempfile.TemporaryDirectory() as t:
    repo = os.path.join(t, "ZenHub"); os.makedirs(repo)
    subprocess.run(["git", "init", "-q", "-b", "main", repo])
    open(os.path.join(repo, "README.md"), "w").write("hub\n")
    subprocess.run(["git", "-C", repo, "add", "-A"]); subprocess.run(["git", "-C", repo, "-c", "user.name=x", "-c", "user.email=x@x", "commit", "-qm", "init"])
    fa = os.path.join(t, "fa"); fb = os.path.join(t, "fb"); os.makedirs(fa); os.makedirs(fb)
    add_version(fa, 1, "1", "2026-11-01", {"a.pdf": b"a1"}, rid=2001, concept="2000")
    add_version(fb, 1, "1", "2026-11-02", {"b.pdf": b"b1"}, rid=3001, concept="3000")
    r1 = z.run(["--repo", repo, "--fixture", fa]); r2 = z.run(["--repo", repo, "--fixture", fb])
    add_version(fa, 2, "2", "2026-11-20", {"a.pdf": b"a2"}, rid=2002, concept="2000")
    r3 = z.run(["--repo", repo, "--fixture", fa])
    tg = sorted(tags_of(repo))
    st = json.load(open(os.path.join(repo, "records", "zenodo-2000", "MIRROR_STATE.json")))
    check("R1", r1 == r2 == r3 == 0 and tg == ["zenodo-2000-v1", "zenodo-2000-v2", "zenodo-3000-v1"]
          and st["mirrored"] == ["2001", "2002"]
          and open(os.path.join(repo, "records", "zenodo-3000", "files", "b.pdf"), "rb").read() == b"b1"
          and open(os.path.join(repo, "README.md")).read() == "hub\n",
          "two records share one repository in their own folders; second run updates only record 2000")
    check("R2", subprocess.run(["git", "-C", repo, "status", "--porcelain", "--", "records/zenodo-2000", "records/zenodo-3000"],
          capture_output=True, text=True).stdout == "", "record folders are fully committed")
    import zenodo_to_github as zz
    a = zz.re.search(r"(\d+)\s*/?\s*$", "https://zenodo.org/records/23489288".split("?")[0]).group(1)
    check("R3", a == "23489288", "a pasted zenodo.org/records/NNN link is read as record NNN")

# ---------------- version-list paging against a fake Zenodo (no network)
import urllib.error
def fake_api(pages_ok, n):
    vers = [{"id": 5000 + k} for k in range(n)]
    def gj(url):
        if "size=" in url and not pages_ok:
            raise urllib.error.HTTPError(url, 400, "BAD REQUEST", {}, None)
        if "size=" in url:
            size = int(url.split("size=")[1].split("&")[0]); page = int(url.split("page=")[1].split("&")[0])
            return {"hits": {"hits": vers[(page-1)*size: page*size], "total": n}}
        return {"hits": {"hits": vers[:10], "total": n}}
    return gj
orig = z.get_json
rec0 = {"id": 5000, "links": {"versions": "https://example.invalid/api/records/5000/versions"}}
z.get_json = fake_api(True, 60)
got = z.all_versions(rec0)
check("P1", len(got) == 60 and len({g["id"] for g in got}) == 60, "60 versions read over three pages of 25")
z.get_json = fake_api(False, 4)
got = z.all_versions(rec0)
check("P2", len(got) == 4, "a 400 on the paged request falls back to the plain request")
z.get_json = fake_api(False, 40)
try:
    z.all_versions(rec0); ok = False
except SystemExit as e:
    ok = "STOP" in str(e.code)
check("P3", ok, "if the plain request cannot return every version, it stops instead of mirroring part")
z.get_json = orig
print("\n".join(res))

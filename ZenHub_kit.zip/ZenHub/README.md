# ZenHub

## What this repository is

A mirror of published Zenodo records. Zenodo is the record of origin for everything here;
cite the Zenodo DOI given in each record's folder, not this repository.

## Layout

- records/zenodo-NNN/ holds one Zenodo record (NNN is the number Zenodo uses for all its versions).
  Each Zenodo version is one commit and one tag, zenodo-NNN-vX.
- tools/ holds the mirror tool and its offline tests.
- .github/workflows/mirror-zenodo.yml is the "Run workflow" button.

## How a record is added or updated

1. Publish on Zenodo first.
2. Open the Actions tab, choose "Mirror a Zenodo record", press "Run workflow" and paste the record number or link.
3. The run tests the tool, downloads the record's versions from Zenodo's public API, checks every file against
   Zenodo's checksum, scans for private names and machine paths, and commits only versions not already here.
   If any check fails, nothing is pushed and the run's summary page says why.

## Rule

This repository must never be switched on under Zenodo > Settings > GitHub; that would make every
GitHub release a second Zenodo record of the same work.

## Credit

Tool made by Loia Labs LLC.
